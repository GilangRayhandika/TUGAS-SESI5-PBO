/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kendaraan;

/**
 *
 * @author komputer jarkom 7
 */
public class Kendaraan {

    public Kendaraan(java.lang.String namaPemilik, java.lang.String nomorPlat, java.lang.String jenisKendaraan) {
        this.namaPemilik = namaPemilik;
        this.nomorPlat = nomorPlat;
        this.jenisKendaraan = jenisKendaraan;
    }
    String namapemilik;
    String nomorplat;
    String jeniskendaraan;
    private final String namaPemilik;
    private final String nomorPlat;
    private final String jenisKendaraan;
    private String sedang;
    
    //Constructor
    public void tampilkanInfo() {
        System.out.println("Nama Pemilik: " + namaPemilik);
        System.out.println("Nomor Plat: " + nomorPlat);
        System.out.println("Jenis Kendaraan: " + jenisKendaraan);
    }

    public void serviceKendaraan() {
        System.out.println("Servis kendaraan sedang dilakukan.");
    }

    public void serviceKendaraan(String jenisServis) {
        System.out.println("Servis jenis " + jenisServis + " sedang dilakukan.");
    }

}

