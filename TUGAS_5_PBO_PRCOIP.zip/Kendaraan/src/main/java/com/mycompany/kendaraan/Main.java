/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kendaraan;

/**
 *
 * @author komputer jarkom 7
 */
public class Main {
    public static void main(String[] args) {
        Mobil mobil1 = new Mobil("Heri", "B 1234 AB", 4);
        Motor motor1 = new Motor("Heri", "D 5678 CD", true);
        
        //Memanggil method tampilkan info
        System.out.println("\nInformasi Kendaraan:");
        mobil1.tampilkanInfo();
        System.out.println();
        motor1.tampilkanInfo();
        
        //Memanggil method serviceKendaraan
        System.out.println("\nServis Kendaraan:");
        mobil1.serviceKendaraan();
        motor1.serviceKendaraan("Ganti Oli");
    
    }
    }
