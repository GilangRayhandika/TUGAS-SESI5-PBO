/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kendaraan;

/**
 *
 * @author komputer jarkom 7
 */
public class Motor extends Kendaraan {
    boolean memilikiBox;

    public Motor(String namaPemilik, String nomorPlat, boolean memilikiBox) {
        super(namaPemilik, nomorPlat, "Motor");
        this.memilikiBox = memilikiBox;
    }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Memiliki Box: " + (memilikiBox ? "Ya" : "Tidak"));
    }

    public void setMemilikiBox(boolean memilikiBox) {
        this.memilikiBox = memilikiBox;
    }

    public boolean isMemilikiBox() {
        return memilikiBox;
    }
    }

    
    
    

